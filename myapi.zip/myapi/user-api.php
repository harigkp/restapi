<?php
	
/* File : user-api.php
	 * Author : Hari Ram Sharma
	*/

	ini_set("memory_limit","256M");
	ini_set('max_execution_time', 1200);
	
	require_once("Rest.inc.php");
	require_once("api.php");
	
	class API extends REST {
	
		public $data = "";
		private $db = NULL;
		private $user_name = NULL;
		private $pass = NULL;
		private $token_id = NULL;
		private $gDbConn = NULL;
		private $config = NULL;
		
		public function __construct()
		{
			parent::__construct();				// Init parent contructor
			
		}
		
		/*
		 * Public method for access api.
		 * This method dynmically call the method based on the query string
		 *
		 */
		public function processApi(){

			$func = strtolower(trim(str_replace("/","",$_REQUEST['rquest'])));
		/*	$this->user_name = 'hari';
			$this->pass = 'hari';
			$this->token_id = md5(rand(99,99999));  */
			if((int)method_exists($this,$func) > 0)
			{
				$this->$func();
			}
			else
			{
				$this->response('',404);				// If the method not exist with in this class, response would be "Page not found".
			}
		}
		
		/* This is API Login */	
		
		function login(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
			
			$ret = $config->authentication($data['username'],$data['password']);

			if($ret=='0'){
				$outputdata = array( 'code' => '401','message' => 'Authentication Failed');							
				$this->response($config->json($outputdata), 200);					
			}elseif($ret=='1'){
				$$outputdata = array( 'code' => '500','message' => 'Internal Server Error');
				$this->response($config->json($outputdata), 200);			
			} else {
				$outputdata = array( 'code' => '200','message' => 'Successful login','job_id' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}


		function token_session()
		{
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
			
			session_start();
			$_SESSION['api_token'] = $data['job_id'];
			
			$outputdata = array( 'code' => '200','message' => 'Successful');							
			$this->response($config->json($outputdata), 200);			

		}
		
		/* This is API Logout 
		function logout(){
			
			$result = file_get_contents('php://input');
			//$data = json_decode($result, TRUE);
			$config = new config_api;
			$gDbConn = $config->dbConnect();
			
			if($data['job_id']<>"")
			{
				$bd['token_id'] =$data['token_id'];
								
				$result4 = $gDbConn->query("select '1' as check from service_job where token_id = '"$data['token_id'].."'");
				
				if(count($result4) > 0)
				{										

					$result5 = $gDbConn->query("delete from service_job where token_id = '"$data['token_id'].."'");
					$outputdata = array( 'code' => '200','message' => 'Logout');
				    $this->response($config->json($outputdata), 200);		
				}
				else
				{
					$outputdata = array( 'code' => '404','message' => 'Token ID not found');
				    $this->response($config->json($outputdata), 200);
				}
			}
			
		}
		*/	


/* User Section */

		function usersignup(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
            
			$ret = $config->check_user_exist($data['email']);
			
			if($ret=='1'){
				$outputdata = array( 'code' => '200','message' => 'User already exist');							
				$this->response($config->json($outputdata), 200);				
			}else{			
				$ret = $config->user_signup($data['email'],$data['password'],$data['full_name'],$data['music_cat'],$data['payment']);

				if($ret=='1'){
					$outputdata = array( 'code' => '200','message' => 'Successful signup');							
					$this->response($config->json($outputdata), 200);				
				}elseif($ret=='0'){
					$outputdata = array( 'code' => '500','message' => 'Internal Server Error');
					$this->response($config->json($outputdata), 200);			
				}
			}
			
		}
		


		function web_user_login(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
			
			$ret = $config->webuserauth($data['email'],$data['password']);

			if($ret=='0'){
				$outputdata = array( 'code' => '401','message' => 'Authentication Failed');							
				$this->response($config->json($outputdata), 200);					
			}elseif($ret=='1'){
				$$outputdata = array( 'code' => '500','message' => 'Internal Server Error');
				$this->response($config->json($outputdata), 200);			
			} else {
				session_start();
				$_SESSION['uid'] = $ret;
				$outputdata = array( 'code' => '200','message' => 'Successful login','user_id' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}



		function user_data(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
			
			$ret = $config->webuserdata($data['user_id']);
			session_start();
			$_SESSION['full_name']= $ret['full_name'];
			$_SESSION['payment']= $ret['payment'];			
			$_SESSION['register_cat']= $ret['music_cat'];
            if($ret){
				$outputdata = array( 'code' => '200','message' => 'Successful get data','user_data' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}



		function song_by_catid(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
			
			$ret = $config->song_by_cat($data['cat_id']);

            if($ret){
				$outputdata = array( 'code' => '200','message' => 'Successful get data','song_data' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}



		function get_my_cat(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
			
			$ret = $config->get_cat_detail($data['cat_id']);

            if($ret){
				$outputdata = array( 'code' => '200','message' => 'Successful get data','cat_data' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}




		function get_music_cat(){
		
			$config = new config_api;
			
			$ret = $config->music_cat();
			
			//echo $ret; die;
				
            if($ret){
				$outputdata = array( 'code' => '200','message' => 'Successful get data','musict_cat_data' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}




		function addplaylist(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
            
			$ret = $config->check_user_playlist($data['userid'],$data['playlist_name']);
			
			if($ret=='1'){
				$outputdata = array( 'code' => '200','message' => 'playlist already exist');							
				$this->response($config->json($outputdata), 200);				
			}else{			
				$ret = $config->add_playlist($data['userid'],$data['playlist_name']);

				if($ret=='1'){
					$outputdata = array( 'code' => '200','message' => 'Successful added');							
					$this->response($config->json($outputdata), 200);				
				}elseif($ret=='0'){
					$outputdata = array( 'code' => '500','message' => 'Internal Server Error');
					$this->response($config->json($outputdata), 200);			
				}
			}
			
		}






		function playlist_by_user(){
			
			$result = file_get_contents('php://input');
			$data = $this->jsondecode($result, TRUE);
			$config = new config_api;
			
			$ret = $config->user_playlist($data['userid']);

            if($ret){
				$outputdata = array( 'code' => '200','message' => 'Successful get data','playlist_data' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}






		function all_song(){
			
			$result = file_get_contents('php://input');
			$config = new config_api;
			
			$ret = $config->allsong();

            if($ret){
				$outputdata = array( 'code' => '200','message' => 'Successful get data','song_data' => $ret);							
				$this->response($config->json($outputdata), 200);	
			}	
			
		}








		
		/*
		 *	Encode array into JSON
		*/
		private function json($data){
			if(is_array($data)){
				return json_encode($data, JSON_UNESCAPED_SLASHES);
				//return json_encode($data);
			}
		}
		
		private function jsondecode($data){
			//if(is_json($data)){
				return json_decode($data, JSON_UNESCAPED_SLASHES);
				//return json_encode($data);
			//}
		}		
		
		
	}
	
	// Initiiate Library
	$api = new API;
	$api->processApi();
	
?>
