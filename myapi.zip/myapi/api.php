<?php

	/* File : api.php
	 * Author : Hari Ram Sharma
	*/
	
	class config_api{
	      function dbConnect(){
			
			try {
 	   			 $gDbConn = new mysqli("localhost","root","","apidb");
			} catch (Exception $e) {
    			echo 'Caught exception: ',  $e->getMessage(), "\n";
			}	
			
			return $gDbConn;
		}
		
		
		
		function authentication($user,$pass)
		{
			$gDbConn = $this->dbConnect();

			$user_name  = $user;
			$pass  = $pass;
			

	
			$sql = "select '1' as authenticated, pl.id as person_id
					from api_login pl
					where pl.user = '".$user_name."'
					and pl.pass = md5('".$pass."')	
			";	
			
			/* Authentication */
			$result_q = $gDbConn->query($sql);
			
			$result = $result_q->fetch_array();
			
			
			if($result_q->num_rows > 0)
			{
				$authenticated = true;
			}
			else
			{	
				$authenticated = false;
			}
			/* Authentication */
			if($authenticated)
			{
				$bd = array();

				        $bd['Varperson_id'] = $result['person_id'];

						$result_check = $gDbConn->query("select token_id from service_job where person_id = ".$bd['Varperson_id']);						
						$result_check_data = $result_check->fetch_array();						
												
						if($result_check->num_rows > '0'){		
												  
						  return $result_check_data['token_id'];
						  
						} else {	
												
							$bd['token_id'] = md5(rand(99,99999));		
							$result3 = $gDbConn->Query("insert into service_job (token_id, person_id, create_date) values('".$bd['token_id']."', ".$bd['Varperson_id'].", now())"); 
							return $bd['token_id'];
						}
					

			} else {
			return 0;	
			}
		}
		


		function user_signup($email,$pass,$full_name,$music_cat,$payment)
		{
			$gDbConn = $this->dbConnect();

			$email  = $email;
			$pass  = $pass;
			
			   $data_execute = $gDbConn->Query( "insert into web_user(email,password,full_name,music_cat,payment) values ('".$email."','".md5($pass)."','".$full_name."',".$music_cat.",".$payment.")");	
			/* Authentication */
			if($data_execute)
			{
				return 1;

			} else {
			return 0;	
			}
		}
		

		function check_user_exist($email)
		{
			$gDbConn = $this->dbConnect();

			$result_check = $gDbConn->query("select id from web_user where email = '".trim($email)."'");						

			/* Authentication */
			if($result_check->num_rows > '0'){
				return 1;

			} else {
			return 0;	
			}
		}




		function webuserauth($email,$pass)
		{
			$gDbConn = $this->dbConnect();

	
			$sql = "select '1' as authenticated, u.id as user_id
					from web_user u
					where u.email = '".$email."'
					and u.password = md5('".$pass."')	
			";	
			
			/* Authentication */
			$result_q = $gDbConn->query($sql);
			
			$result = $result_q->fetch_array();
			
			
			if($result_q->num_rows > 0)
			{
				$authenticated = true;
			}
			else
			{	
				$authenticated = false;
			}
			/* Authentication */
			if($authenticated)
			{

				      return  $result['user_id'];
					

			} else {
			return 0;	
			}
		}


        
		function webuserdata($uid)
		{
			$gDbConn = $this->dbConnect();

			$result_q = $gDbConn->query("select full_name,music_cat,payment from web_user where id=".$uid);			

			$result = $result_q->fetch_array();
			
			return $result;
		}


		function song_by_cat($catid)
		{
			$gDbConn = $this->dbConnect();

			$result_q = $gDbConn->query("select id,song from songs where catid=".$catid);			
			
			//$result = $result_q->fetch_array();
			
			$jsonData = array();
			while ($result = $result_q->fetch_array()) {
				$jsonData[] = $result;
			}			
		   return json_encode($jsonData);
		}




		function get_cat_detail($catid)
		{
			$gDbConn = $this->dbConnect();

			$result_q = $gDbConn->query("select name from music_cat where id=".$catid);		

			$result = $result_q->fetch_array();

			return $result['name'];
		}





		function music_cat()
		{
			$gDbConn = $this->dbConnect();

			$result_q = $gDbConn->query("select * from music_cat");			
			
			//$result = $result_q->fetch_array();
			
			$jsonData = array();
			while ($result = $result_q->fetch_array()) {
				$jsonData[] = $result;
			}			
		   return json_encode($jsonData);
		}




		function check_user_playlist($userid,$playlist_name)
		{
			$gDbConn = $this->dbConnect();

			$result_check = $gDbConn->query("select id from playlist where userid=".$userid." and  name = '".trim($playlist_name)."'");						

			/* Authentication */
			if($result_check->num_rows > '0'){
				return 1;

			} else {
			return 0;	
			}
		}



		function add_playlist($userid,$playlist_name)
		{
			$gDbConn = $this->dbConnect();
			
			   $data_execute = $gDbConn->Query( "insert into playlist(name,userid) values ('".$playlist_name."',".$userid.")");	

			if($data_execute)
			{
				return 1;

			} else {
			return 0;	
			}
		}


		function user_playlist($userid)
		{
			$gDbConn = $this->dbConnect();

			$result_q = $gDbConn->query("select id,name from playlist where userid=".$userid);			
			
			$jsonData = array();
			while ($result = $result_q->fetch_array()) {
				$jsonData[] = $result;
			}			
		   return json_encode($jsonData);
		}



		function allsong()
		{
			$gDbConn = $this->dbConnect();

			$result_q = $gDbConn->query("select * from songs");			
			
			//$result = $result_q->fetch_array();
			
			$jsonData = array();
			while ($result = $result_q->fetch_array()) {
				$jsonData[] = $result;
			}			
		   return json_encode($jsonData);
		}





		/*
		 *	Encode array into JSON
		*/
		function json($data){
			if(is_array($data)){
				//return json_encode($data, JSON_UNESCAPED_SLASHES);
				return json_encode($data);
			}
		}
		
		
		function jsonencode($data){
			if(is_array($data)){
				
				return str_replace('\\/', '/', json_encode($data));
				
				//return json_encode($data, JSON_UNESCAPED_SLASHES);
				//return json_encode($data);
			}
		}
				
		
		
		function jsondecode($data){
			if(is_json($data)){
				return json_decode($data, JSON_UNESCAPED_SLASHES);
				//return json_encode($data);
			}
		}
				
		

	}
?>
