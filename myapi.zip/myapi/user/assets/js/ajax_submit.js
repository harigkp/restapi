$(document).ready(function () {
	$("#signup").submit(function(e) {
		e.preventDefault(); 
		var form = $(this);
		var actionUrl = form.attr('action');
		var data = form.serializeArray();
		
		$.ajax({
			type: "POST",
			url: actionUrl,
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify(getFormData(data)),			
			success: function(data)
			{
				var getResponse =  JSON.stringify(data); 
				var res = JSON.parse(getResponse);

				if(res.message=='User already exist'){
					$("#msg").removeAttr('class');
					$("#msg").addClass("error");
					$("#msg").html("User already exist");
				}else{
					$("#msg").removeAttr('class');
					$("#msg").addClass("green");
					$("#msg").html("Successful signup");					
					
				}
			  
			}
		});
		
	});
	
	
	
	

	$("#login").submit(function(e) {
		e.preventDefault(); 
		var form = $(this);
		var actionUrl = form.attr('action');
		var data = form.serializeArray();
		
		$.ajax({
			type: "POST",
			url: actionUrl,
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify(getFormData(data)),			
			success: function(data)
			{
				var getResponse =  JSON.stringify(data); 
				var res = JSON.parse(getResponse);
			
				alert(res.message);

				if(res.message=='Authentication Failed'){
					$("#loginmsg").removeAttr('class');
					$("#loginmsg").addClass("error");
					$("#loginmsg").html("Authentication Failed");
				}else{
					$("#msg").removeAttr('class');
					$("#msg").addClass("green");
					$("#msg").html("Successful signup");

					window.location.href = "http://localhost/myapi/user/dashboard";					
					
				}
			  
			}
		});
		
	});		
	
	
	
	
	

});


//utility function
function getFormData(data) {
   var unindexed_array = data;
   var indexed_array = {};

   $.map(unindexed_array, function(n, i) {
    indexed_array[n['name']] = n['value'];
   });

   return indexed_array;
}