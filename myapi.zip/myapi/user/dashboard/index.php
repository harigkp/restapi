<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>User Dashboard</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <?php include("head.php");?>

</head>

<body>

  <!-- ======= Header ======= -->
<?php include("header.php");?>
  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      


    </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            <!-- Sales Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">

                <div class="card-body">
                  <h5 class="card-title">My Songs</h5>

                  <div class="d-flex align-items-center">
                    

					  <div id="myplaylist"></div>
                  
                  </div>
                </div>

              </div>
            </div><!-- End Sales Card -->

            <!-- Revenue Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">

                <div class="card-body">
                  <h5 class="card-title">My song category</h5>

                  <div class="d-flex align-items-center">
                    
                      <div id="mycat"></div>
                   
                  </div>
                </div>

              </div>
            </div><!-- End Revenue Card -->

            <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-12">

              <div class="card info-card customers-card">

                <div class="card-body">
                  <h5 class="card-title">My playlist</span></h5>

                  <div class="d-flex align-items-center">
                    <div id="userplaylist"></div>
                    

                  </div>
				  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#basicModal">
                Add playlist
              </button>
			  <div class="modal fade" id="basicModal" tabindex="-1" style="display: none;" aria-hidden="true">
                <div class="modal-dialog">
				<form id="addplaylist" class="sign-in-htm" action="http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=addplaylist" method="post">
				<input type="hidden" name="userid" value="<?php echo $_SESSION['uid'];?>" />
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Add playlist</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
					
                      <input type="text" name="playlist_name" id="playlist_name" required />
					  <p id="msg"></p>
					  </form>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                      <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                  </div>
				  </form>
                </div>
              </div>
			  
			  
			  
			  
			  
                </div>
              </div>

            </div><!-- End Customers Card -->

          </div>
        </div><!-- End Left side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php include("footer.php")?>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>


<script>
$(document).ready(function () {
	$("#addplaylist").submit(function(e) {
		e.preventDefault(); 
		var form = $(this);
		var actionUrl = form.attr('action');
		var data = form.serializeArray();
		
		$.ajax({
			type: "POST",
			url: actionUrl,
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify(getFormData(data)),			
			success: function(data)
			{
				var getResponse =  JSON.stringify(data); 
				var res = JSON.parse(getResponse);

				if(res.message=='playlist already exist'){
					$("#msg").removeAttr('class');
					$("#msg").addClass("error");
					$("#msg").html("playlist already exist");
				}else{
					$("#msg").removeAttr('class');
					$("#msg").addClass("green");
					$("#msg").html("Successful added");					
					
				}
			  
			}
		});
		
	});
	
	
	
	
		/* Get User song by register cat  */
		
			$.ajax({
			type: "POST",
			url: 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=song_by_catid',
			dataType: 'json',
			contentType: 'application/json',
			data: '{"cat_id":"<?php echo $_SESSION['register_cat'];?>"}',			
			success: function(data)
			{

				var getResponse =  JSON.stringify(data); 	
				var res = JSON.parse(getResponse);
				var res1 = JSON.parse(res.song_data);
				var str = '<ul class="list-group">'

				for (var i = 0; i < res1.length; i++) {
				  str += '<li class="list-group-item"><i class="bi bi-file-earmark-music"></i>'+ res1[i].song + '</li>';
				}

				str += '</ul>';
				
				document.getElementById("myplaylist").innerHTML = str;
				
			}
		});		
			
	
	
	
		/* Get User playlist */
		
			$.ajax({
			type: "POST",
			url: 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=playlist_by_user',
			dataType: 'json',
			contentType: 'application/json',
			data: '{"userid":"<?php echo $_SESSION['uid'];?>"}',			
			success: function(data)
			{

				var getResponse =  JSON.stringify(data); 	
				var res = JSON.parse(getResponse);
				var res1 = JSON.parse(res.playlist_data);
				
				var str = '<ul class="list-group">'

				for (var i = 0; i < res1.length; i++) {
str += '<li class="list-group-item"><i class="bi bi-file-earmark-music"></i><a href="http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user/dashboard/add_song.php?playlist='+ res1[i].id + '&playlistname='+ res1[i].name + '">'+ res1[i].name + '</a></li>';
				}

				str += '</ul>';
				
				document.getElementById("userplaylist").innerHTML = str;
				
			}
		});

		/* Get User register cat  */
		
			$.ajax({
			type: "POST",
			url: 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=get_my_cat',
			dataType: 'json',
			contentType: 'application/json',
			data: '{"cat_id":"<?php echo $_SESSION['register_cat'];?>"}',			
			success: function(data)
			{

				var getResponse =  JSON.stringify(data); 	
				var res = JSON.parse(getResponse);
				document.getElementById("mycat").innerHTML = res.cat_data;
				
			}
		});		
	
});
</script>