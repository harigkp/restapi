<footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>My API</span></strong>. All Rights Reserved
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<script  src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="	  crossorigin="anonymous"></script>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/js/ajax_submit.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    <script>
  $(document).ready(function () {
	/* Get User data */
			$.ajax({
			type: "POST",
			url: 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=user_data',
			dataType: 'json',
			contentType: 'application/json',
			data: '{"user_id":"<?php echo $_SESSION['uid'];?>"}',			
			success: function(data)
			{
				var getResponse =  JSON.stringify(data); 
				var res = JSON.parse(getResponse)
			}
		});
		
		

//get music	
	
		$.ajax({
			type: "GET",
			url: 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=all_song',
			dataType: 'json',
			contentType: 'application/json',				
			success: function(data)
			{

				var getResponse =  JSON.stringify(data); 	
				var res1 = JSON.parse(getResponse);
				var res = JSON.parse(res1.song_data	);				
				
				
				for (var i = 0; i < res.length; i++) {
					var select = document.getElementById("songid");
					var option = document.createElement("option");
					option.text = res[i].song;
					option.value = res[i].id;
					select.appendChild(option);
				}
			}
		});			
			
});				
			
			
			
			
			
			
  </script>