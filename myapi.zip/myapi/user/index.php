<?PHP
session_start();

if(!isset($_SESSION['api_token']) && $_SESSION['api_token']==""){
	header("location:../index.php");
}

?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PHP API</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
      <link rel="stylesheet" href="./assets/css/style.css">
	  
<script  src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="	  crossorigin="anonymous"></script>
		
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
  <script src="./assets/js/ajax_submit.js"></script>
</head>
<body>
  <div class="login-wrap">
  <div class="login-html">
    <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
    <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
    <div class="login-form">
      <form id="login" name="login" class="sign-in-htm"action="http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=web_user_login" method="POST">
        <div class="group">
          <label for="email" class="label">Email</label>
          <input id="email" name="email" type="email" class="input" required>
        </div>
        <div class="group">
          <label for="pass" class="label">Password</label>
          <input id="password" name="password" type="password" class="input" data-type="password" required>
        </div>
        <div class="group">
          <input id="check" type="checkbox" class="check" checked>
          <label for="check"><span class="icon"></span> Keep me Signed in</label>
        </div>
        <div class="group">
          <input type="submit" class="button" value="Sign In">
        </div>
        <div class="hr"></div>
         <div class="foot-lnk">
          <label for="tab-2">Not a Member?</a>
        </div>
      </form>
      <form id="signup" name="signup" class="sign-up-htm" action="http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=usersignup" method="POST">
        <div class="group">
          <label for="Email" class="label">Email</label>
          <input id="email" name="email" type="email" class="input">
        </div>
        <div class="group">
          <label for="pass" class="label">Password</label>
          <input id="password" name="password" type="password" class="input" data-type="password">
        </div>
        <div class="group">
          <label for="full_name" class="label">Your Name</label>
          <input id="full_name" name="full_name" type="text" class="input" class="input">
        </div>
        <div class="group">
          <label for="music_cat" class="label">Music Category</label>
          <select name="music_cat" id="music_cat" style="color:#888484 !important" class="input">
		</select>
        </div>
        <div class="group">
          <label for="payment" class="label">Making payment</label>
          <select name="payment" id="payment" style="color:#888484 !important" class="input" aria-label="Default select example">
		  <option value="1">Yes</option>
		  <option value="2">No</option>
		</select>
        </div>		
        <div class="group">
          <input type="submit" class="button" value="Sign Up">
		  <p id="msg" class="green"></p>
        </div>
        <div class="hr"></div>
        <div class="foot-lnk">
          <label for="tab-1">Already Member?</a>
        </div>
      </form>
    </div>
  </div>
</div>
  
  
</body>
</html>

<script>


$(function() {
  $("form[name='signup']").validate({
    rules: {
	  full_name:{required: true},
	  music_cat:{required: true},
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }   
    },
    messages: {
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },

  });
  
  
//Login   
  
   $("form[name='login']").validate({
    rules: {
      email: {
        required: true,
        email: true
      },
      password: {
        required: true,
      }  
    },
    messages: {
      password: {
        required: "Please provide a password",
      },
      email: "Please enter a valid email address"
    },

  }); 
  
  
//get music category	
	
		$.ajax({
			type: "GET",
			url: 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=get_music_cat',
			dataType: 'json',
			contentType: 'application/json',	
            data: '{"music_cat":"1"}',				
			success: function(data)
			{
				var getResponse =  JSON.stringify(data); 
				var res = JSON.parse(getResponse);
				for (var i = 0; i < res.length; i++) {
					var select = document.getElementById("music_cat");
					var option = document.createElement("option");
					option.text = res[i].name;
					option.value = res[i].id;
					select.add(option);
				}
			}
		});	  
  
  
  
  
  
});



</script>