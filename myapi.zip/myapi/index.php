<?php session_start();?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PHP API</title>
  
  
  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Open+Sans:600'>
      <link rel="stylesheet" href="./assets/css/style.css">
	  
<script  src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo="	  crossorigin="anonymous"></script>
		
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
  
</head>
<body>
  <div class="login-wrap">
  <div class="login-html">
    <label for="tab-1" class="tab">API Login</label>
    <div class="login-form">
      <form id="loginapi" class="sign-in-htm" action="http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=login" method="post">
        <div class="group">
          <label for="user" class="label">Username</label>
          <input id="username" name="username" type="text" class="input" required>
        </div>
        <div class="group">
          <label for="pass" class="label">Password</label>
          <input id="password" name="password" type="password" class="input" data-type="password" required>
        </div>
        <div class="group">
          <input type="submit" class="button" value="Sign In">
        </div>
      </form>
    </div>
  </div>
</div>
  
  
</body>
</html>

<script>

$(document).ready(function () {
	$("#loginapi").submit(function(e) {

		e.preventDefault(); 
		var form = $(this);
		var actionUrl = form.attr('action');
		var data = form.serializeArray();
		
		$.ajax({
			type: "POST",
			url: actionUrl,
			dataType: 'json',
			contentType: 'application/json',
			data: JSON.stringify(getFormData(data)),			
			success: function(data)
			{
				
				var getResponse =  JSON.stringify(data); 
				var response_data = JSON.parse(getResponse);

				if(response_data.code==200){
				        alert("Successful login");
						$.ajax({
							type: "POST",
							url: 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user-api.php?rquest=token_session',
							data: '{"job_id":"'+response_data.job_id+'"}',			
							success: function(data)
							{
								var getResponse_token_session =  JSON.stringify(data); 
								var getResponse_token_data = JSON.parse(getResponse_token_session);
								
								if(getResponse_token_data.code==200){
									window.location.href = 'http://<?php echo $_SERVER['HTTP_HOST'];?>/myapi/user/';
								}
							  
							}				
					
					});
				}
			  
			}
		});
		
	});

});


//utility function
function getFormData(data) {
   var unindexed_array = data;
   var indexed_array = {};

   $.map(unindexed_array, function(n, i) {
    indexed_array[n['name']] = n['value'];
   });

   return indexed_array;
}

</script>