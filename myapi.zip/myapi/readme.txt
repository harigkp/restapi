1. first login to api -> user/password is hari/hari
2. Then signup and login of user
3. then get all songs for logged-in user API
4. create playlist in dashboard
5. Add songs to playlist API.  This in only remaining